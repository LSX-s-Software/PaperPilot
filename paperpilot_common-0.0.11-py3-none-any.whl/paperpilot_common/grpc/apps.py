# -*- coding: utf-8
from django.apps import AppConfig


class DjangoGrpcConfig(AppConfig):
    name = "paperpilot_common.grpc"
    verbose_name = "Django gRPC server"
